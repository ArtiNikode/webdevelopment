#!C:\Users\ASUS\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Python 3.9\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='artinikode',database='automobileshowroomdb')
curs=con.cursor()

form=cgi.FieldStorage()
userid=form.getvalue("userid")
password=form.getvalue("password")


curs.execute("insert into users values('%s','%s')" %(userid,password))
con.commit()

print("<h3>User login successful</h3>")
print("<a href='frontpage.html'>home page</a>")

con.close()
