#!C:\Users\ASUS\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Python 3.9\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='artinikode',database='automobileshowroombdb')
curs=con.cursor()

form=cgi.FieldStorage()
now=form.getvalue("numberofwheels")
encp=form.getvalue("enginecapacity")
comp=form.getvalue("company")
ftp=form.getvalue("fueltype")
pri=form.getvalue("price")
cty=form.getvalue("cartype")


curs.execute("insert into customers values('%s','%s','%s','%s','%s','%s')" %(now,encp,comp,ftp,pri,cty))
con.commit()

print("<h3>Car registration successful</h3>")
print("<a href='frontpage.html'>home page</a>")

con.close()
