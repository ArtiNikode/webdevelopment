#!C:\Users\ASUS\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Python 3.9\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='artinikode',database='automobileshowroombdb')
curs=con.cursor()

form=cgi.FieldStorage()
id=form.getvalue("custid")
nm=form.getvalue("name")
eid=form.getvalue("emailid")
mo=form.getvalue("mobileno")
add=form.getvalue("address")
gen=form.getvalue("gender")


curs.execute("insert into customers values('%s','%s','%s','%s','%s','%s')" %(id,nm,eid,mo,add,gen))
con.commit()

print("<h3>User registration successful</h3>")
print("<a href='frontpage.html'>home page</a>")

con.close()
